export class Producto{
    constructor(
        public id: number,
        public nombre: string,
        public precioP: number,
        public imagen: string
    ){}
}